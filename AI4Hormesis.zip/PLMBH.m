clear all
clc

%%%数据DS2(Dataset31)---DS11
Dss = [0         5      10       20      30       60     100     125     160    200];
Rs = [100.312 100.312 113.025 125.142 155.931 113.224 69.7219 39.5289 20.0624 4.56867];
n = length(Dss); %%%数据长度
%%%参数

% %%%%%%%%%%rho,      lambda,     theta,      a0,          a1,           a2,       a3
parlb = [10^(-4),       1,        0.1,     10^(-2),      -10^(-2),   -10^(-5),   -10^(-7)]; %%下界
parub = [1,             50,        0.5,       1,          10^(-2),    10^(-5),   10^(-7)]; %%上界
par1guess = [0.01       30        0.2        0.2          10^(-3)     10^(-6)    10^(-8)];
%%%最优参数值：

% options = optimset('Display','final','MaxIter',5000,'MaxFunEvals',5000);
% [par, fval] = fmincon(@LSmin, par1guess,[ ],[ ],[ ],[ ],parlb,parub,[],options,Rs)


%%%利用最优参数绘图
par = [0.0146   17.4126    0.2898    0.2263   -0.0034    9.999510248412716e-06    9.999929831694445e-08] 
% 19.6636
[Rs_simu] = model_sol(par);
d = LSmin(par,Rs);
RMSE = sqrt (  1/n*sum( (Rs_simu - Rs).^2 )  ); 
MAE = 1/n*sum( abs(Rs_simu - Rs) ); 
RE = sqrt ( sum( (Rs_simu - Rs).^2 )  )/sqrt( sum(Rs.^2) );
[RMSE MAE RE]

figure(1)
plot(0:n-1,Rs,'o--','color',[178/255,190/255,195/255],'linewidth',2,'MarkerFaceColor',[178/255,190/255,195/255]) %%%'MarkerEdgeColor',colorplus(202),
hold on
plot(0:n-1,Rs_simu,'s-','Color',colorplus(194),'markersize',8,'linewidth',2,'MarkerFaceColor',colorplus(194))
set(gca,'XTick',[0:1:n-1])
set(gca,'XTickLabel',{'0','5','10','20','30','60','100','125','160','200'})
h11=legend('Dataset 11', 'Fitted by PLM-BH','FontName','Times New Roman','FontSize',12,'Location','southwest');
legend('boxoff')
h12=xlabel('Crude Oil (ppm)','fontsize',12,'FontName','Times New Roman'); 
h13=ylabel('Growth (% of control)','fontsize',12,'FontName','Times New Roman');
set(gca,'fontweight','bold')
set(gca,'linewidth',1)

% figure(1)
% plot(0:n-1,Rs_simu,'p--','color',colorplus(190),'markersize',6,'linewidth',2,'MarkerFaceColor',colorplus(213)) %%%'MarkerEdgeColor',colorplus(202),
% hold on


%%%定义最小二乘法的目标函数
function d = LSmin(par1,Rs) 
[Rs_simu1] = model_sol(par1);
d = norm(Rs_simu1 - Rs);
end


%%%模型求解
function [Rs_simu] = model_sol(par1)
Ds = [0         5      10       20      30       60     100     125     160    200];
rho = par1(1);
lambda = par1(2);
theta = par1(3);
a0 = par1(4);
a1= par1(5);
a2 = par1(6);
a3 = par1(7);

Re_simu = zeros(1,length(Ds));
for i = 1:length(Ds)
    p = exp(-rho*Ds(i)); 
%     p = (1-pm)*exp(-rho*Ds(i)) + pm;
    
%     %%% 近似计算平衡点
%     x = 0:0.001:300;
%     f =  lambda * p * (theta*( exp(-x.*( alpha + beta*exp(-r*x) )) )...
%         + (1-theta)*( exp(-p*x.*( alpha + beta*exp(-r*x*p) )) )) - 1;
%     [f1,f2] = min(abs(f));
%     Rs_simu(i) = x(f2);

    %%% 模型稳态 迭代500次，取最后450-500个点的平均
    iter = 2000;
    N(1) =  100*rand; %rand;%0.2
    for t=1:iter
        N(t+1) = lambda * p * N(t) * (  theta/( 1+N(t)*(a0 + a1*N(t) + a2*N(t)^2 + a3*N(t)^3) )...
            + (1-theta)/( 1+ p*N(t)*(a0 + a1*p*N(t) + a2*(p*N(t))^2 + a3*(p*N(t))^3) )  );
    end
    Rs_simu(i) = mean(N(1850:end)); 

end



end


