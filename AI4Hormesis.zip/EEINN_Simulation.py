"""
测试代码对于非时间序列的可行性
"""
"""
参数推断结果保存在Noise中
"""

"""
基于Hiromi Seno 2008年MBS上的文章所用的模型
假设种群以Ricker模式增长
测试噪声数据
"""

import os
import time
import tensorflow as tf
import numpy as np
import pandas
import matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline
import scipy.io
from scipy.interpolate import griddata
from pyDOE import lhs
from matplotlib import cm
from matplotlib.ticker import LinearLocator

# import os
# os.environ["CUDA_VISIBLE_DEVICES"] = "0"  #

start_time = time.time()

np.random.seed(42)
tf.set_random_seed(42)

with tf.device('/cpu:0'):
    class EEINN:
        def __init__(self, Ds_train, Rs_train, d_f, lb, ub, layers, sf):


            self.sf = sf

            # Data for training
            self.Ds_train = Ds_train
            self.Rs_train = Rs_train
            self.d_f = d_f

            # bounds
            self.lb = lb
            self.ub = ub

            # initailize NN
            self.weights, self.biases = self.initialize_NN(layers)

            # parameters

            bound_rho = [0.01, 0.25]
            bound_lamda = [7, 15]
            bound_theta = [0.001, 0.07]
            bound_r = [0.01, 0.1]

            self.rho = bound_rho[0] + (bound_rho[1] - bound_rho[0]) * tf.sigmoid(tf.Variable([0.15], dtype=tf.float32, trainable=True))
            self.lamda = bound_lamda[0] + (bound_lamda[1] - bound_lamda[0]) * tf.sigmoid(tf.Variable([0.3], dtype=tf.float32, trainable=True))
            self.theta = bound_theta[0] + (bound_theta[1] - bound_theta[0]) * tf.sigmoid(tf.Variable([0.31], dtype=tf.float32, trainable=True))
            self.r = bound_r[0] + (bound_r[1] - bound_r[0]) * tf.sigmoid(tf.Variable([0.1], dtype=tf.float32, trainable=True))


            # tf placeholders and graph
            self.sess = tf.Session(config=tf.ConfigProto(allow_soft_placement=True,
                                                         log_device_placement=True))
            # self.saver = tf.train.Saver()

            # placeholder for inputs
            self.Ds_u = tf.placeholder(tf.float32, shape=[None, self.Ds_train.shape[1]])
            self.x_u = tf.placeholder(tf.float32, shape=[None, self.Rs_train.shape[1]])
            self.d_df = tf.placeholder(tf.float32, shape=[None, self.d_f.shape[1]])

            # physics informed neural network
            self.xequilibra_pred = self.net_u(self.Ds_u)

            self.P = tf.exp(-self.rho*self.Ds_u)

            self.x_res = self.net_f(self.d_df)

            self.constr = self.net_constr(self.Ds_u)


            # loss
            # self.lossU0 = tf.reduce_mean(tf.square(self.x0_u - self.x0_pred))

            self.lossU = tf.reduce_mean(tf.square(self.x_u - self.xequilibra_pred))

            self.lossF = tf.reduce_mean(tf.square(self.x_res))

            self.lossconstr = tf.norm(self.constr, ord=1, axis=0)

            self.loss = self.lossU + 200*self.lossF + self.lossconstr #
            # self.loss = self.lossU0 + self.lossU + self.lossF #

            # Optimizer

            # self.optimizer = tf.train.AdamOptimizer(1e-3)
            # self.train_op_Adam = self.optimizer.minimize(self.loss)

            self.optimizer = tf.contrib.opt.ScipyOptimizerInterface(self.loss,
                                                                    method='L-BFGS-B',
                                                                    options={'maxiter': 50000,
                                                                             'maxfun': 50000,
                                                                             'maxcor': 50,
                                                                             'maxls': 50,
                                                                             'ftol': 1.0 * np.finfo(float).eps})

            self.optimizer_Adam = tf.train.AdamOptimizer(0.001)
            self.train_op_Adam = self.optimizer_Adam.minimize(self.loss)

            init = tf.global_variables_initializer()
            self.sess.run(init)

        # Initialize the neural network
        def initialize_NN(self, layers):
            weights = []
            biases = []
            num_layers = len(layers)
            for l in range(0, num_layers - 1):
                W = self.xavier_init(size=[layers[l], layers[l + 1]])  # weights for the current layer
                b = tf.Variable(tf.zeros([1, layers[l + 1]], dtype=tf.float32),
                                dtype=tf.float32)
                weights.append(W)
                biases.append(b)
            return weights, biases

        # generating weights
        def xavier_init(self, size):
            in_dim = size[0]
            out_dim = size[1]
            xavier_stddev = np.sqrt(2 / (in_dim + out_dim))
            return  tf.Variable(tf.truncated_normal([in_dim, out_dim], stddev=xavier_stddev), dtype=tf.float32)

                # tf.Variable(tf.truncated_normal([in_dim, out_dim], stddev=xavier_stddev, dtype=tf.float32),
                #                dtype=tf.float32)

        # Architecture of the neural network
        def neural_net(self, Ds, weights, biases):
            num_layers = len(weights) + 1
            H = Ds
            # H =  (Ds - self.lb) / (self.ub - self.lb)

            # H = 2.0 * (Ds - self.lb) / (self.ub - self.lb) - 1.0
            for l in range(0, num_layers - 2):
                W = weights[l]
                b = biases[l]
                H = tf.tanh(tf.add(tf.matmul(H, W), b))
            W = weights[-1]
            b = biases[-1]
            Y = tf.add(tf.matmul(H, W), b)
            return Y


        def net_u(self, Ds):
            output = self.neural_net(Ds, self.weights, self.biases)
            x = output
            # x = output[:, 0:1]
            return x


        def net_constr(self, Ds):

            rho = self.rho
            lamda = self.lamda
            theta = self.theta
            r = self.r

            x = self.net_u(Ds)

            p = tf.exp(-rho * Ds)
            h = tf.exp(-r*x)

            xp = p * x
            hp = tf.exp(-r*xp)

            F = lamda * p * x * (theta * h + (1 - theta) * hp)

            F_x = tf.gradients(F, x)[0]
            f_d = tf.abs(F_x) - 1
            f_constr = tf.maximum(tf.cast(0,dtype=tf.float32), f_d)
            return f_constr

        def net_f(self, Ds):

            # load the parameters
            rho = self.rho
            lamda = self.lamda
            theta = self.theta
            r = self.r

            # betaI = self.net_BetaI(t, F)
            x = self.net_u(Ds)

            p = tf.exp(-rho * Ds)
            h = tf.exp(-r*x)

            xp = p * x
            hp = tf.exp(-r*xp)

            f_x = lamda * p * (theta*h + (1-theta)*hp) - 1

            return f_x


        def train(self, nIter):

            tf_dict = {self.Ds_u: self.Ds_train, self.d_df: self.d_f,
                         self.x_u: self.Rs_train
                        }#,self.d_df: self.d_f,

            start_time = time.time()
            for it in range(nIter + 1):
                self.sess.run(self.train_op_Adam, tf_dict)

                # Print
                if it % 100 == 0:
                    elapsed = time.time() - start_time
                    loss_value = self.sess.run(self.loss, tf_dict)
                    lossU_value = self.sess.run(self.lossU, tf_dict)
                    lossF_value = self.sess.run(self.lossF, tf_dict)
                    lamda_value = self.sess.run(self.lamda)
                    rho_value = self.sess.run(self.rho)
                    theta_value = self.sess.run(self.theta)
                    r_value = self.sess.run(self.r)

                    total_records.append(
                        np.array([it, loss_value, lossU_value, lossF_value]))
                    print(
                        'It: %d, Loss: %.3e, LossU: %.3e, LossF: %.3e, rho: %.4e, Time: %.2f' %
                        (it, loss_value, lossU_value, lossF_value, rho_value, elapsed))
                    start_time = time.time()

            # if LBFGS:
            # self.optimizer.minimize(self.sess,
            #                         feed_dict=tf_dict,
            #                         fetches=[self.loss, self.lossU0, self.lossU, self.lossF, self.beta, self.gamma],
            #                         loss_callback=self.callback)

        def predict(self, Ds_star):

            tf_dict = {self.Ds_u: Ds_star}
            # x_state = []
            x_state = self.sess.run(self.xequilibra_pred, tf_dict)

            return x_state


    if __name__ == "__main__":
        layers = [1] + 3 * [32] + [1]

        data_frame = pandas.read_excel('Data/Datapoints5.xlsx')

        Dss = data_frame['Dss']
        Rs = data_frame['Rs']
        Rs_true= data_frame['Rs']

        Ds_star = Dss
        Ds_star = Ds_star.to_numpy(dtype=np.float32)
        Ds_star = Ds_star[0:]

        Ds_star = Ds_star.reshape([len(Ds_star), 1])

        Rs_star = Rs
        # Rs_star = Rs_star.rolling(window=7).mean()
        Rs_star = Rs_star.to_numpy(dtype=np.float32)
        Rs_star = Rs_star[0:]

        Rs_true = Rs_true.to_numpy(dtype=np.float32)
        Rs_true = Rs_true[0:]

        Rs_star = Rs_star.reshape([len(Rs_star), 1])

        # lower and upper bounds
        lb = Ds_star.min(0)
        ub = Ds_star.max(0)

        sf = 1
        Rs_star = Rs_star * sf

        # Residual points
        N_f = 100
        # d_f = lb + (ub - lb) * lhs(1, N_f)
        d_f = np.linspace(lb, ub, num=N_f)

        x_f = np.linspace(lb, ub, num=N_f)
        # x_f = lb + (ub - lb) * lhs(1, N_f)

        N_pred = 100
        Ds_Pred = np.linspace(lb, ub, num=N_pred)

        ######################## Training and Predicting #####################
        ######################################################################
        Ds_train = Ds_star
        Rs_train = Rs_star

        from datetime import datetime

        now = datetime.now()
        dt_string = now.strftime("%y-%m-%d")

        # save results
        current_directory = os.getcwd()

        for j in range(1):

            casenumber = 'set' + str(j + 1)
            relative_path_results = '/Simulation/Training-results-' + dt_string + '-' + casenumber + '/'
            save_results_to = current_directory + relative_path_results
            if not os.path.exists(save_results_to):
                os.makedirs(save_results_to)

            ####model
            total_records = []
            # total_records_LBFGS = []
            model = EEINN(Ds_train, Rs_train, d_f, lb, ub, layers, sf)
            ####Training
            # LBFGS = True
            # LBFGS=False
            model.train(10000)  # Training with n iterations

            lamda_value = model.sess.run(model.lamda)
            rho_value = model.sess.run(model.rho)
            theta_value = model.sess.run(model.theta)
            r_value = model.sess.run(model.r)

            p_value = np.exp(-rho_value * Ds_Pred)

            print('lamda:', lamda_value)
            print('theta', theta_value)
            print('rho', rho_value)
            print('r', r_value)

            """Relative Error"""
            lamda_actual = 10
            theta_actual = 0.05
            rho_actual = 0.15
            r_actual = 0.03

            lamda_RE = np.abs(lamda_value - lamda_actual) / lamda_actual
            theta_RE = np.abs(theta_value - theta_actual) / theta_actual
            rho_RE = np.abs(rho_value - rho_actual) / rho_actual
            r_RE = np.abs(r_value - r_actual) / r_actual

            print('lamda_RE:', lamda_RE)
            print('theta_RE', theta_RE)
            print('rho_RE', rho_RE)
            print('r_RE', r_RE)


            xstable = model.predict(Ds_Pred)

            ###################### save data ######################
            np.savetxt(save_results_to + 'Dstrain.txt', Ds_train.reshape((-1, 1)))
            np.savetxt(save_results_to + 'xstable.txt', xstable.reshape((-1, 1)))
            np.savetxt(save_results_to + 'Ds_pred.txt', Ds_Pred.reshape((-1, 1)))
            np.savetxt(save_results_to + 'p.txt', p_value.reshape((-1, 1)))

            ####################### save parameters ###############################
            np.savetxt(save_results_to + 'lamda.txt', lamda_value.reshape((-1, 1)))
            np.savetxt(save_results_to + 'rho.txt', rho_value.reshape((-1, 1)))
            np.savetxt(save_results_to + 'theta.txt', theta_value.reshape((-1, 1)))
            np.savetxt(save_results_to + 'r.txt', r_value.reshape((-1, 1)))

            plt.figure(1)

            plt.plot(Ds_star, Rs_star, 'b.', lw=2, markersize=8, label='noise data')
            plt.plot(Ds_star, Rs_true, 'g.', lw=2, markersize=8, label='real data')
            plt.plot(Ds_Pred, xstable / sf, 'r-', lw=2, label='EEINN')

            plt.legend()
            plt.show()



