clear all
clc

%%%数据DS2(Dataset31)---DS11
Dss = [0         5      10       20      30       60     100     125     160    200];
Rs = [100.312 100.312 113.025 125.142 155.931 113.224 69.7219 39.5289 20.0624 4.56867];
n = length(Dss); %%%数据长度
%%%参数
% % %%%%%%%%%%rho,       lambda,    theta,      alpha,      beta,        r
% parlb = [1,            0.01,      0.01,       10^(-5),    10^(-5),     10^(-5)]; %%下界
% parub = [50,            200,       0.5,         1,          1,           1]; %%上界
% par1guess = [10         26         0.1        0.001      0.001       0.001];

% %%%%%%%%%%rho,       lambda,    theta,      alpha,      beta,        r
parlb = [10^(-3),      1,        0.1,       10^(-5),    10^(-5),     10^(-5)]; %%下界
parub = [1,             50,       0.5,         1,          1,           0.1]; %%上界
par1guess = [0.018       22       0.2       0.028       0.175     0.0513];
%%%最优参数值： 
% 
% options = optimset('Display','final','MaxIter',5000,'MaxFunEvals',5000);
% [par, fval] = fmincon(@LSmin, par1guess,[ ],[ ],[ ],[ ],parlb,parub,[],options,Rs)


%%%利用最优参数绘图
par = [0.017969032211668   21.978795709200043   0.190464350924330   0.026970887314271   0.179752717636797   0.055508139902501]

% par = [0.0176   21.9738    0.1948    0.0272    0.1542    0.0522];
[Rs_simu] = model_sol(par);
d = LSmin(par,Rs);
RMSE = sqrt (  1/n*sum( (Rs_simu - Rs).^2 )  ); 
MAE = 1/n*sum( abs(Rs_simu - Rs) ); 

% 计算残差
residuals = Rs_simu - Rs;

% R² (决定系数)
ss_res = sum(residuals.^2);
ss_tot = sum((Rs - mean(Rs)).^2);
R2 = 1 - (ss_res / ss_tot);

RE = sqrt ( sum( (Rs_simu - Rs).^2 )  )/sqrt( sum(Rs.^2) );
[RMSE MAE RE]
figure(1)
plot(0:n-1,Rs,'o-.','Color',[178/255,190/255,195/255],'markersize',8,'linewidth',2,'MarkerFaceColor',[178/255,190/255,195/255]) %%%'MarkerEdgeColor',colorplus(202),
hold on
plot(0:n-1,Rs_simu,'s-','Color',colorplus(194),'markersize',8,'linewidth',2,'MarkerFaceColor',colorplus(194))
set(gca,'XTick',[0:1:n-1])
set(gca,'XTickLabel',{'0','5','10','20','30','60','100','125','160','200'})
h11=legend('Dataset 11', 'Fitted by PLM-Ricker','FontName','Times New Roman','FontSize',12,'Location','southwest');
legend('boxoff')
h12=xlabel('Sodium Arsenate (\muM)','fontsize',12,'FontName','Times New Roman'); 
h13=ylabel('Survival (% of control)','fontsize',12,'FontName','Times New Roman');
set(gca,'fontweight','bold')
set(gca,'linewidth',1)
title('(A)','fontsize',16,'FontName','Times New Roman')

% 
% figure()
% plot(0:n-1,Rs,'o-.','color',colorplus(186),'markersize',8,'linewidth',2,'MarkerFaceColor',colorplus(205)) %%%'MarkerEdgeColor',colorplus(202),
% hold on
% plot(0:n-1,Rs_simu,'s-','Color',colorplus(108),'markersize',8,'linewidth',2,'MarkerFaceColor',colorplus(313))
% set(gca,'XTick',[0:1:n-1])
% set(gca,'XTickLabel',{'0','5','10','20','30','60','100','125','160','200'})
% h11=legend('Dataset 11', 'Fitted by PLM-Ricker','FontName','Times New Roman','FontSize',12,'Location','northwest');
% legend('boxoff')
% h12=xlabel('Crude Oil (ppm)','fontsize',12,'FontName','Times New Roman'); 
% h13=ylabel('Growth (% of control)','fontsize',12,'FontName','Times New Roman');
% set(gca,'fontweight','bold')
% set(gca,'linewidth',1)


% figure()
% h1(1) = plot(0:n-1,Rs,'o--','color',colorplus(42),'linewidth',1.5,'MarkerFaceColor','k');
% hold on
% h1(2) = plot(0:n-1,Rs_simu,'s-','color',colorplus(108),'linewidth',2,'MarkerFaceColor','r');
% hold on
% xlabel('IFN\gamma (ng/ml)')
% ylabel('TNF-\alpha Secretion (%)')
% legend(h1,{'DS2','Simulation'});
% set(gca,'XTickLabel',{'0', '0.01', '0.05', '0.5', '5', '10', '20', '40'})
% line([0 n-1],[-1/b*log(mu/r) -1/b*log(mu/r)],'Color','b','LineStyle','--','LineWidth',1.5)


%%%定义最小二乘法的目标函数
function d = LSmin(par1,Rs) 
[Rs_simu1] = model_sol(par1);
% d = norm(Rs_simu1 - Rs);
d = sqrt ( sum( (Rs_simu1 - Rs).^2 )  )/sqrt( sum(Rs.^2) );
end


%%%模型求解
function [Rs_simu] = model_sol(par1)
Ds = [0 5 10 20 30 60 100 125 160 200];
rho = par1(1);
lambda = par1(2);
theta = par1(3);
alpha = par1(4);
beta= par1(5);
r = par1(6);
Re_simu = zeros(1,length(Ds));
for i = 1:length(Ds)
    p = exp(-rho*Ds(i)); 
%     p = (1-pm)*exp(-rho*Ds(i)) + pm;
    
%     %%% 近似计算平衡点
%     x = 0:0.001:300;
%     f =  lambda * p * (theta*( exp(-x.*( alpha + beta*exp(-r*x) )) )...
%         + (1-theta)*( exp(-p*x.*( alpha + beta*exp(-r*x*p) )) )) - 1;
%     [f1,f2] = min(abs(f))
%     Rs_simu(i) = x(f2);

    %%% 模型稳态 迭代500次，取最后450-500个点的平均
    iter = 5000;
    N(1) =  100*rand; %rand;%0.2
    for t=1:iter
        N(t+1) = lambda * p * N(t) * (theta*( exp(-N(t)*( alpha + beta*exp(-r*N(t)) )) )...
        + (1-theta)*( exp(-p*N(t)*( alpha + beta*exp(-r*N(t)*p) )) ));
    end
    Rs_simu(i) = mean(N(4550:end)); 

end



end


